local seconds = Config.AlarmLength
local AlertTypes = {
    ["missiles"] = 1,
    ["hostileAircraftIntrusion"] = 2,
}

local function ArrayLength(ar)
    local count = 0
    for k,v in pairs(ar) do
        count+=1
    end
    return count
end

CreateThread(function()
    local firing = false
    while true do
        Wait(4000)
        PerformHttpRequest("https://redalert.me/alerts", function(err, text, headers) 
            print(err)
            if text then
                cjson = json.decode(text)
                if cjson then
                    local rtv = {}
                    local ostime = os.time()
                    for k, v in pairs(cjson) do
                        if v['threat'] and AlertTypes[v['threat']] then
                            local alertTime = os.date("*t", v['date'])
                            
                            if ostime - os.time(alertTime) <= seconds then
                                rtv[v['area']] = AlertTypes[v['threat']]
                            end
                        end
                    end
                    if ArrayLength(rtv) ~= 0 then
                        if not firing then
                            firing = true
                        end
                        TriggerClientEvent('israel-alerts', -1, rtv)
                    else
                        if firing then
                            TriggerClientEvent('israel-alerts', -1, {})
                            firing = false;
                        end
                    end
                end
            end
        end)
        
    end
end)