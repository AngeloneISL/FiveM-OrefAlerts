# israel-alerts
Red alerts script for FiveM

Original Idea by barbaroNN, Fixed & Improved by Angelone.

Preview:
![image](https://user-images.githubusercontent.com/49079109/183177504-e9afc5b7-89f4-4844-9e6a-7c150850f2e3.png)
"# FiveM-OrefAlerts" 
