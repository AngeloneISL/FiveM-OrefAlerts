Config = {}
Config.ImageScreen = false
Config.AlarmLength = 11145 -- in seconds
Config.AlertSide = "right" -- right/left ( which side the alerts will appear )
Config.AnimationTime = 1000